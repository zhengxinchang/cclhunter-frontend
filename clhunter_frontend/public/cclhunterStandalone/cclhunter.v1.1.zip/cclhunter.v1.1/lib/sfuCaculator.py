from pickle import TRUE
import numpy as np
import pandas as pd
import sys,json
import logging
from scipy.stats import kendalltau
#from combat.pycombat import pycombat


def sfu_pipeline(lib,test_col=0):
#    batch=['query' for i in range(len(lib.columns.tolist())-1)]
#    batch=['query']
#    batch.extend(['subject' for i in range(len(lib.columns.tolist())-1)])
#    for i in range(len(lib.columns.tolist())-2):
#        lib.insert(0,i,lib['QUERY'])
#    lib=pycombat(lib.fillna(0),batch,mean_only=True)

    case=pd.Series(lib.iloc[:,int(test_col)],dtype=float)
    lib.drop(lib.columns[0],axis=1,inplace=True)
    results_dict={}
    for per in lib:
        control=pd.Series(lib[per],dtype=float)
        getSFU=sfu_caculator(case,control)
        results_dict.update(kendallTau(getSFU))
    return results_dict

def kendallTau(sfu_df):
    case=np.array(sfu_df[sfu_df['sfu']==1].iloc[:,3]) #TEST sample
    control=np.array(sfu_df[sfu_df['sfu']==1].iloc[:,4]) #reference in our database vectorB
    corr=kendalltau(case, control)
    correlation=corr.correlation
    pvalue=corr.pvalue
    rank='|'.join(sfu_df['rank'].values.tolist())
    is_sfu='|'.join([str(int(_)) for _ in sfu_df['sfu'].values.tolist()]) #dtype=float
    smooth=lm(sfu_df[sfu_df['sfu']==1].loc[:,'rank'].values.tolist())
    return {sfu_df.columns[4]:{'correlation':correlation,'pvalue':pvalue,'rank':rank,'sfu':is_sfu,'lm':smooth}}

def lm(array):
    array=[int(_) for _ in array]
    lm=np.polyfit(x=list(range(len(array))),y=array,deg=1)
    return(list(lm))

def sfu_caculator(case,control):

    control_norm=(control-control.mean())/control.std() 
    case_norm=(case-case.mean())/case.std()

#    control_norm=(control-control.min())/(control.max()-control.min())
#    control_norm=control_norm+control_norm.min()
#    case_norm=(case-case.min())/(case.max()-case.min())
#    case_norm=case_norm+case_norm.min()


    log=np.log2((case_norm+0.01)/(control_norm+0.01))
    log[np.isinf(log)]=np.nan
    log=log.dropna()
    log.name='log'
    log.index.name='rsid'
    #mean=abs(np.log2(case_norm)+np.log2(control_norm))/2
    mean=(case_norm-control_norm)
    mean[np.isinf(mean)]=np.nan
    mean=mean.dropna()
    mean.name='mean'
    mean.index.name='rsid'

    new_pd=pd.concat([log,mean],axis=1)
    new_pd.columns=['log','mean']

    mean_per=np.percentile(mean,(25,75))
    log_per=np.percentile(log,(25,75))

    logging.debug(f'#mean: {mean_per}')
    logging.debug(f'#log: {log_per}')

#    mean_out=mean[(np.percentile(mean,10)<mean ) & (mean<np.percentile(mean,90))] #中间
    mean_g=mean[np.percentile(mean,10)<mean]
    mean_l=mean[np.percentile(mean,90)>mean]
    mean_out=pd.Series(list(set(mean_g.index).intersection(set(mean_l.index))))
    mean_out=mean[mean_out.tolist()]
#    mean_g=mean[mean<np.percentile(mean[mean>0],(50))]
#    mean_g=mean_g[mean_g>0]
#    mean_l=mean[mean>np.percentile(mean[mean<0],(50))]
#    mean_l=mean_l[mean_l<0]
#    mean_out=pd.concat([mean_g,mean_l])
#    log_out=log[((log<np.percentile(log,35)) & (log<0)) | ((log>np.percentile(log,65)) & (log>0))]
    log_g=log[log<np.percentile(log,40)]
    #log_g=log_g[log_g<0]
    log_l=log[log>np.percentile(log,60)]
    #log_l=log_l[log_l>0]
    log_out=pd.concat([log_g,log_l])

#    log_out=log[(log<np.percentile(log,20)& (log<0)) | (log>np.percentile(log,80)& (log>0)) ]
#    log_g=log[log<np.percentile(log[log<0],(50))]
#    log_l=log[log>np.percentile(log[log>0],(50))]
#    log_out=pd.concat([log_g,log_l])
   

    value_list=[]

    for i in new_pd.index:
        if i in (set(mean_out.index)&set(log_out.index)):
            value_list.append(1)
        else:
            value_list.append(0)

    new_pd.insert(loc=len(new_pd.columns),column='sfu',value=value_list)
    new_pd=pd.concat([new_pd,case,control],axis=1).dropna(axis=0)

    new_pd.sort_values(by=control.name,inplace=True)
    new_pd.insert(loc=len(new_pd.columns),column='rank',value=[str(_) for _ in range(len(new_pd))])
    new_pd.sort_values(by=case.name,inplace=True)

    logging.debug(new_pd)
    return(new_pd)

if __name__ == '__main__':
    try:
        input=sys.argv[1]
    except:
        input='/pnas/pmod/bucongfan/BCF202109150001/01.snpVector_B/cellid_test/CVCL_0002.small.exp'

    exp=pd.read_csv(input,sep='\t',index_col=0)
    ref_exp='/pnas/pmod/bucongfan/BCF202109150001/01.snpVector_B/cellid_test/refdata/usedgene.counts.final.rs'
    ref_lkg='/pnas/pmod/bucongfan/BCF202109150001/01.snpVector_B/cellid_test/CellTree.CutCCLEAndCOSMIC.LKG'
    def process_cellTreeLKG(f):
        this_dict={}
        with open(f) as fcelltree:
            for per in fcelltree:
                level,cellLine,lkg_list=per.strip().split('\t')
                this_dict[cellLine]={'level':level,'lkg':[_ for _ in lkg_list.split(',')]}
        return this_dict
    def process_snpvectorA(f, LKG, test_dict):
        ref_exp=pd.read_csv(f,sep='\t',index_col=0)
        refine_LKG=list(set(LKG['lkg']).intersection(set([_ for _ in ref_exp])))
        ref_exp_LKG=ref_exp[refine_LKG]
        if type(test_dict) == type({}):
            test_rsid=[]
            test_count=[]
            for i in test_dict:
                test_rsid.append(i)    
                test_count.append(test_dict[i])    
            test_exp=pd.DataFrame(test_count,index=test_rsid,columns=['QUERY'])
        else:
            test_exp=test_dict
            test_exp.name='QUERY'
        return pd.concat([test_exp,ref_exp_LKG],axis=1)

    cellTreeLKG_dict=process_cellTreeLKG(ref_lkg)
    print('#query\tLKG\tsubject\tcorr\tpvalue')
    for query_name in exp.columns:
        query=exp.loc[:,query_name]
        if query_name in cellTreeLKG_dict:
            lkg_list= cellTreeLKG_dict[query_name]
            this_lkg='|'.join(lkg_list['lkg'])
            snplibA  = process_snpvectorA(ref_exp,LKG=lkg_list,test_dict=query)
            results_dict=sfu_pipeline(snplibA)
            for subject in results_dict:
                corr=results_dict[subject]['correlation']
                pval=results_dict[subject]['pvalue']
                judge='yes' if query_name == subject else 'no'
                print(f'{query_name}\t{this_lkg}\t{subject}\t{corr}\t{pval}\t{judge}')
