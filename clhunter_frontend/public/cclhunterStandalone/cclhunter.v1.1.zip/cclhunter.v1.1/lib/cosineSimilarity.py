#!/usr/bin/env python3

import sys
import os
from collections import OrderedDict
import numpy as np
import pandas as pd
import logging

def compare_genotype(a,b):
    """
    compare genotype
    AG = GA
    """
    lista = [x for x in a ]
    listb = [x for x in b ]
    lista.sort()
    listb.sort()
    if lista == listb:
        return True
    else:
        return False

def get_one_hot(genotype):
    """
    input a genotype like AA
    output a 10 length vector
    """
    ONE_HOT_LIST = ["AA","TT","CC","GG","AT","AC","AG","TC","TG","CG"]
    index = -1
    for i,k in enumerate(ONE_HOT_LIST):
        if compare_genotype(k,genotype):
            index = i
    if index >0 :
        pre = [0 for x in range(0,index)]
        post = [0 for x in range(index+1,len(ONE_HOT_LIST))]
        return(pre + [1] +post)
    else:
        return [0 for x in range(0,len(ONE_HOT_LIST))]
    

def one_hot_encode_sequence(vec):
    """
    one hot encode 
    AA TT CC GG AT AC AG TC TG CG
    1 genotype encode 10 length sequence
    vec:
    AA|CC|GT|AC
    """
    vec_list = vec.strip().split("|")
    one_hot_sequence = []
    for genotype in vec_list:
        one_hot_sequence.extend(get_one_hot(genotype))
    return(one_hot_sequence)


def cosine_similarity(str_x,str_y):
    x = np.array(one_hot_encode_sequence(str_x))
    y = np.array(one_hot_encode_sequence(str_y))
    num = x.dot(y.T)
    denom = np.linalg.norm(x) * np.linalg.norm(y) # 求范数乘积
    logging.debug(f"x:{str_x}\ny:{str_y}")
    try:
        t = num / denom
    except:
        t=-1
        logging.error(f"x:{x}\ny:{y}")
    return t

def calculateAllB(snp_status_in_in_bam,cellVectors,top):
    '''
    返回raw similarity 和adjust simiarity 
    '''
    raw_similarity=OrderedDict()
    cellid_similarity=OrderedDict()
    try:
        user_vector = "|".join(snp_status_in_in_bam.values()) #this_seqstr
    except Exception as e:
        print(snp_status_in_in_bam)
        print(e)
        exit
    raw_similarity["this"]='QUERY'
    raw_similarity["this_seqstr"]=user_vector
    raw_similarity['similar']=[]



    # filter out snps with NN genotype in user_vector. and this snp in cellvectors will also be filtered out.    
    adjust_user_snps = OrderedDict()
    for k,v in snp_status_in_in_bam.items():
        if v.upper() != "NN":
            adjust_user_snps[k] = v
    
    adjust_snpvectorB = OrderedDict()
    for cellid,snpDict in cellVectors.items():
        rawSNPVector = "|".join([k for k in snpDict.values()])
        cellid_similarity[cellid]={"cvclid":cellid,"similarity":None,"seqstr":rawSNPVector}
        tmpDict = OrderedDict()
        for k,v in snpDict.items():
            if k in adjust_user_snps.keys():
                tmpDict[k]=v
        adjust_snpvectorB[cellid] =tmpDict
    
    adj_raw_similarity=OrderedDict()
    adj_user_vector = "|".join(adjust_user_snps.values())
    logging.debug(f"adj user_vector:{user_vector}")
    for cellid, vecB in adjust_snpvectorB.items():
        adjSNPVector = "|".join([k for k in vecB.values()])
        logging.debug(f"adjSNPVector:{adjSNPVector}")
        adjsimilarity = cosine_similarity(adj_user_vector, adjSNPVector)
        logging.debug(
            "cell line : {} , adj similarity : {}".format(str(cellid), str(adjsimilarity))
        )
        adj_raw_similarity[str(cellid)] = adjsimilarity

    adj_raw_similarity_top=sorted(adj_raw_similarity.items(),key=lambda item:item[1],reverse=True)[:top]
    for cellid,similarity in adj_raw_similarity_top:
        try:
            cellid_similarity[cellid]["similarity"]=similarity
            raw_similarity['similar'].append(cellid_similarity[cellid])
        except Exception as e:
            logging.error(e)

    logging.debug(f"user_vector:{user_vector}")

    
    # logging.debug(f"raw snps: {len(snp_status_in_in_bam.values())} {snp_status_in_in_bam}")
    # logging.debug(f"raw cell snps:{len(cellVectors.values())}  {cellVectors}")
    # logging.debug(f"filterd snps:{len(adjust_user_snps.values())}  {adjust_user_snps}")
    # logging.debug(f"filterd cell snps{len(adjust_snpvectorB.values())}  {adjust_snpvectorB}")
    # logging.debug(f"raw similarity {raw_similarity}")
    # logging.debug(f"raw similarity {adj_raw_similarity}")
    return((adj_raw_similarity_top[0],relatedCaculator(raw_similarity)))

def baseCompare(ref,query): #TA CT
    rlist=[x for x in ref]
    qlist=[x for x in query]
    rlist.sort()
    qlist.sort()
    '''
    judge:
        4 -> Missing
        3 -> totally same
        2 -> one base same but another is transversion
        1 -> one base same and another is substitution
        0 -> totally different
    '''
    if ref == 'NN':
        return 4
    elif rlist == qlist:
        return 3
    else:
        judging=0
        for i in range(2):
            if rlist[i] == qlist[i]:
                judging+=1
        if judging == 1:
            for i in range(2):
                if rlist[i] == qlist[i]:
                    continue
                else:
                    if (rlist[i] in ('G','C')) and (qlist[i] not in ('G','C')):
                        judging+=1
                    elif (rlist[i] in ('A','T')) and (qlist[i] not in ('A','T')):
                        judging+=1
        return(judging)

def relatedCaculator(this_dict):
    '''
    不改变字典结构的情况下，增加seqstr_related列表，展示genotype的相对值
    host: 受测试的细胞系 TEST, 也写做 ref
    '''
    tmp_dict={}
    host_id=this_dict["this"]
    host_list=this_dict["this_seqstr"].split("|")
    for per_dict in this_dict["similar"]:
        tmp_dict[per_dict["cvclid"]]=per_dict["seqstr"].split("|")
    data=pd.DataFrame(tmp_dict)

    for indexs in data.index:
        ref=host_list[indexs]
        for i,base in enumerate(data.loc[indexs].values[:]):
            data.iloc[indexs,i]=str(baseCompare(ref,base))

    for i,per_dict in enumerate(this_dict["similar"]):
        try:
            new_seqstr="|".join(data[per_dict["cvclid"]].values.tolist())
        except Exception as e:
            sys.stderr.write('{}\n'.format(e))
            exit()
        this_dict["similar"][i]["seqstr_related"]=new_seqstr

    #new_host_list=[str(3) for i in host_list] #primary value, which same with it self
    #this_dict["this_seqstr"]="|".join(new_host_list)

    '''
    New Dict with a socialist makeover
    '''
    return(this_dict)


if __name__ == "__main__":
    try:
        list1=[]
        with open(sys.argv[1]) as Fh:
            for line in Fh:
                list1.append(line.strip().split('\t')[1])
        list2=[]
        with open(sys.argv[2]) as Fh:
            for line in Fh:
                list2.append(line.strip().split('\t')[1])
        print(cosine_similarity("|".join(list1),"|".join(list2)))
    finally:
        ...

    exit()
    import random

    lett = ["AA","TT","CC","GG","AT","AC","AG","TC","TG","CG"]

    for i in range(1,1500):
        seq1 = random.choices(lett,k=100)
        seq2 = random.choices(lett,k=100) 
        print(cosine_similarity("|".join(seq1),"|".join(seq2)))
