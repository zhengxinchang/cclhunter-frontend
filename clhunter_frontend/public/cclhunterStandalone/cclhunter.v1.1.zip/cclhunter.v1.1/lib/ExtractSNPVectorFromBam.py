import logging
import os
import argparse
import subprocess
from collections import Counter
import myGlobal as gvar

def chromosome_has_chr(fbam):
    cmd = "samtools view -H {}  | grep @SQ |head -n 1".format(fbam)
    ret = subprocess.run(
        cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL
    )
    if "CHR" in str(ret.stdout.decode()).upper():
        return(True)
    else:
        return(False)
 

# logging.basicConfig(level=logging.INFO)
def extract_one_position_from_bam(fbam, position):
    """
    调用系统的mpileup命令生成这个位点的数据
    """
    cmd = "samtools mpileup -Q {} -q {} -r {} {}".format(gvar.thisbaseq,gvar.thismapq,position, fbam)
    logging.debug("run cmd: {}".format(cmd))
    ret = subprocess.run(
        cmd, shell=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL
    )
    return ret.stdout.decode()


def process_one_pipeup(s):
    """
    input: （可能为空）from extract_one_position_from_bam
    chr13    95206724        N       1658    >><><<><<t$t$tttTcCCTTCCTcCCT>cCT
    output:
        genotype: 如果有任何异常则返回NN 
    """
    MIN_DEPTH = 2
    MIN_FREQ = 0.15
    x = s.strip()
    if x != "":
        genotype = []
        genotype_str = ""
        bases = x.split("\t")[4]
        count = x.split("\t")[3]
        logging.debug("found bases :{}".format(bases))
        baseList = [m.upper() for m in bases]
        baseCount = Counter(baseList)
        baseCountATCG = {
            "A": baseCount.get("A", 0),
            "G": baseCount.get("G", 0),
            "C": baseCount.get("C", 0),
            "T": baseCount.get("T", 0),
        }
        logging.debug("base count :{}".format(str(baseCountATCG)))
        total_bases = sum(baseCountATCG.values())
        for k, v in baseCountATCG.items():
            if v >= MIN_DEPTH and (v / total_bases) > MIN_FREQ:
                genotype.append(k)
        if len(genotype) == 0:
            logging.debug("len(genotype) == 0,genotype is {}".format(genotype_str))
            genotype_str = "NN"
        elif len(genotype) == 1:
            logging.debug("len(genotype) == 1,genotype is {}".format(genotype_str))
            genotype_str = genotype[0] * 2
        elif len(genotype) == 2:
            logging.debug("len(genotype) == 2,genotype is {}".format(genotype_str))
            genotype_str = "".join(genotype)
        else:
            genotype_str = "NN"

        return genotype_str,count
    else:
        """此位置没有reads 覆盖,genotype = NN"""
        logging.debug("没有捕获,genotype")
        return "NN",0


def extactGenotypeFromBam(bamPath, positionList, check_bam_path=False):
    """
    输入
        bampath
        positionList [{"rsid":"rsxxx","chr":"chr1","pos":1222}]

    输出
    [{"rsid":"rsxxx","chr":"chr1","pos":1222,"genotype":"AA"}]
    AA|CC|GT|AC...
    """
    if check_bam_path:
        if not os.path.exists(bamPath):
            logging.error(f"Bam {bamPath}does not exists...")
            exit(1)

    out = []
    exp = []
    hasChr = chromosome_has_chr(bamPath)
    for onepos in positionList:
        tmp = {
            "rsid": onepos["rsid"],
            "chr": onepos["chr"],
            "pos": onepos["pos"],
        }
        print(f"posssss: {onepos['chr'] if hasChr else onepos['chr'].replace('chr','')}:{onepos['pos']}-{onepos['pos']}")
        ret = extract_one_position_from_bam(
            bamPath, f"{onepos['chr'] if hasChr else onepos['chr'].replace('chr','')}:{onepos['pos']}-{onepos['pos']}"
        )
        print(ret)
        gt,count = process_one_pipeup(ret)
        tmp["genotype"] = gt
        out.append(tmp)
        #exp.append({onepos["rsid"]:count})
        exp.append(f"{onepos['rsid']}\t{count}")
    snpVector = "|".join([x["genotype"] for x in out])
    #exp=[rsid:count,...]
    return (out, snpVector, exp)


if __name__ == "__main__":
    logging.info("Extract genotypes from bam")
    parser = argparse.ArgumentParser()
    parser.add_argument("-b", "--bam", required=True, help="indexed bam file")
    parser.add_argument(
        "-l", "--list", required=True, help="rsid position list rsid\tchr\tpos"
    )
    parser.add_argument(
        "-r",
        "--refver",
        required=False,
        default="hg38",
        help="reference version [hg38,hg19] default is hg38",
    )
    parser.add_argument("-o", "--outprefix", required=True, help="output prefix")
    args = parser.parse_args()
    program_dir = os.path.abspath(__file__)

    # 假pathlist格式
    # [{"rsid":"rsxxx","chr":"chr1","pos":1222,"genotype":"AA"}]
    posList = []
    with open(args.list) as fPosList:
        for x in fPosList:
            xList = x.strip().split("\t")
            posList.append(
                {
                    "rsid": xList[0],
                    "chr": "chr" + xList[3]
                    if not (xList[3].startswith("chr"))
                    else xList[3],
                    "pos": xList[4],
                }
            )
    res = extactGenotypeFromBam(args.bam, posList, check_bam_path=True)
    with open(args.outprefix,'w') as Out:
       Out.write("\n".join('%s' %a for a in res))
    #print(res)
