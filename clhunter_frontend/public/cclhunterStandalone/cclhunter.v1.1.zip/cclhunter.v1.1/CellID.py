#!/usr/bin/python
currversion = "v6"
currdate="2021-01-05"
import argparse
import json
import os,sys
import logging
from collections import OrderedDict
import myGlobal as gvar
import time
import pandas as pd

time_begin = time.time()

libDir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "lib")
refDataDir = os.path.join(os.path.dirname(os.path.abspath(__file__)), "refdata")
SNPvectorA = os.path.join(refDataDir, f"usedgene.counts.final.rs")
SNPvectorB = os.path.join(refDataDir, f"SNPvectorB.{currversion}.txt")
#cellTreeLKG='/pnas/pmod/bucongfan/BCF202109150001/01.snpVector_B/cellid_test/CellTree.LKG'
cellTreeLKG=os.path.join(refDataDir, f"CellTree.CutCCLEAndCOSMIC.LKG")
assert (
    os.path.exists(os.path.join(libDir, "ExtractSNPVectorFromBam.py"))
    and os.path.exists(
        os.path.join(refDataDir, "CellinesProjection.CutCCLEAndCOSMIC.txt")
    )
    and os.path.exists(os.path.join(refDataDir, "CellinesProjection.txt"))
    and os.path.exists(os.path.join(refDataDir, "CellTree.py"))
    and os.path.exists(SNPvectorA)
    and os.path.exists(SNPvectorB)
), "Library files are missing. Please reinstall the program."


def main(bampath, refVer, snpvectorA, snpvectorB, outprefix):
    
    sys.stderr.write(f"""
    ***********************************************

        Cell Line Identification Toolkit({currversion})
        Build date: {currdate}
        Contact: zhengxinchang@big.ac.cn;bucf@big.ac.cn

    ***********************************************
    """)
    from refdata import CellTree
    from lib import ExtractSNPVectorFromBam
    from lib import sfuCaculator
    from lib import cosineSimilarity

    checkbam = os.path.exists(args.bam)
    logging.info(f"Check Bam path...{'ok' if checkbam else 'failed' }")
    if not checkbam:
        exit(1)

    checkbai = os.path.exists(args.bam + ".bai") or os.path.exists(
        os.path.splitext(args.bam)[0] + ".bai"
    )
    logging.info(
        f"Check Bam index...{'ok' if checkbai else 'failed. please build index before run this program.' }"
    )
    if not checkbai:
        exit(1)

    # ===== start to build snp list for snpvectorB
    logging.info("Loading SNP library...")
    snpFromVecterB, cellVectors = process_snpvectorB(snpvectorB, refver=refVer)
    logging.debug(f"snpvectorB:{snpFromVecterB}")
    logging.info("Loading topology of CCLs...")
    cellTreeLKG_dict=process_cellTreeLKG(cellTreeLKG)
    logging.debug(f'Toppology of celltree:{cellTreeLKG_dict}')

    logging.info("Extracting SNP/Pseudo_count from Bam...")
    snp_status_in_in_bam = OrderedDict()
    exp_status_in_in_bam = OrderedDict()
    hasChr = ExtractSNPVectorFromBam.chromosome_has_chr(bampath)
    #for oneRsid, onePos in tqdm.tqdm(snpFromVecterB.items()):
    for oneRsid, onePos in snpFromVecterB.items():
        if hasChr:
            samtoolsPos = onePos["chr"] + ":" + onePos["pos"] + "-" + onePos["pos"]
        else:
            samtoolsPos = onePos["chr"].replace("chr","") + ":" + onePos["pos"] + "-" + onePos["pos"]
        #sys.stderr.write('{}\t.\t.\t{}\t{}\n'.format(oneRsid,onePos["chr"],onePos["pos"]))
        res = ExtractSNPVectorFromBam.extract_one_position_from_bam(
            fbam=bampath, position=samtoolsPos
        )
        snp_status_in_in_bam[oneRsid],exp_status_in_in_bam[oneRsid] = ExtractSNPVectorFromBam.process_one_pipeup(res)
    
    logging.info("Calculating similarity...")
    best_list,user_identity_adj = cosineSimilarity.calculateAllB(snp_status_in_in_bam,cellVectors,top=10)
    logging.debug(f'raw_snp_count:{exp_status_in_in_bam}')
    logging.debug(f'raw_snp_genotype:{snp_status_in_in_bam}')

    logging.info("Identifying celline...")
    max_cellline = {
        "name_snp":None,
        "identity":-1,
        "lkg":None,
        "lkg_topology":None,
        "name_sfu":None,
        "correlation":-1,
        "pvalue":1
    }

    max_cellline["name_snp"] = best_list[0]
    max_cellline["identity"] = best_list[1]
    logging.info(f"Detecting celline with highest similarity: {max_cellline['name_snp']} similarity: {str(max_cellline['identity'])} ")

    ct= CellTree.CellTree()
    lkg_list= cellTreeLKG_dict[max_cellline.get('name_snp')]

    '''
    加入该细胞系拓扑关系
    [细胞系,[child_list]]
    其中细胞系最上层为HumanCellLinesq
    '''
    lkg_topology=[]
    for ccls in lkg_list['lkg']:
        ccls_parent=ct.getParent(ccls)
        ccls_children=ct.getChildren(ccls)
        if ccls_parent == 'HumanCellLines':
            #lkg_topology.append(['HumanCellLines',[ccls]])
            lkg_topology.append({'name':'HumanCellLines','children':[ccls]})
        #lkg_topology.append([ccls,ccls_children])
        lkg_topology.append({'name':ccls,'children':ccls_children})
    max_cellline['lkg_topology']=lkg_topology if lkg_topology else None

    hasChildren = True if len(lkg_list) > 1 else False
    #hasChildren = True #test
    logging.info(f"Check wether this cell line {max_cellline.get('name_snp')} has LKG cell lines...{hasChildren}")
    
    out = {} #初始化结果文件
    out["hits"]=max_cellline
    out["similarity"]=user_identity_adj
    if hasChildren:
        logging.info(f"identifying candidate from LKG {lkg_list}...")
        max_cellline["lkg"]=lkg_list
        snplibA  = process_snpvectorA(snpvectorA,LKG=lkg_list,test_dict=exp_status_in_in_bam)
        user_sfu_identity=sfuCaculator.sfu_pipeline(snplibA)
        if len(user_sfu_identity)>1:
            for ccls in user_sfu_identity:
                cor=user_sfu_identity[ccls]['correlation']
                pva=user_sfu_identity[ccls]['pvalue']
                if float(pva) < max_cellline['pvalue']:
                    max_cellline['name_sfu']=ccls
                    max_cellline['pvalue']=float(pva)
                    max_cellline['correlation']=float(cor)
        
            out["hits"]=max_cellline
            out["sfu_identity"]=user_sfu_identity
    else:
        logging.info("No children cell lines found, building output...")

    logging.info("building output...")


    time_end = time.time()
    outpath_json = outprefix + ".out.json"
    outpath = outprefix + ".out"
    with open(outpath_json,"w") as outf:
        outf.write(json.dumps(out,indent=4))
    with open(outpath,"w") as outf:
        children_name=out["hits"]["name_sfu"]
        children_pvalue=str(out["hits"]["pvalue"])
        children_correlation=str(out["hits"]["correlation"])
        final_result=max_cellline['name_snp'] if children_name is None else children_name
        outf.write('#Authentication\tprefix\tsnp_result|similarity\tsfu_result|LKG|pvalue|correlation\n')
        outf.write('{}\t{}\t{}|{}\t{}|{}|{}|{}\n'.format(final_result,
        outprefix,max_cellline['name_snp'],
        str(max_cellline['identity']),
        children_name,
        ','.join(max_cellline["lkg"]['lkg']),
        children_pvalue,
        children_correlation
        ))
    logging.info("Run time={} seconds".format(round(time_end - time_begin)))
        
def process_cellTreeLKG(f):
    this_dict={}
    with open(f) as fcelltree:
        for per in fcelltree:
            level,cellLine,lkg_list=per.strip().split('\t')
            this_dict[cellLine]={'level':level,'lkg':[_ for _ in lkg_list.split(',')]}
    return this_dict

def process_snpvectorB(f, refver):
    cellines_vectors = OrderedDict()
    snpLib = OrderedDict()
    with open(f) as fsnpvecB:
        for snp in fsnpvecB:
            if snp.strip().startswith("#version="):
                continue
            if snp.strip().startswith("#id"):
                defline = snp.strip()
                rsidList = defline.split(",")[3].split("|")
                for rsid in rsidList:
                    # print(rsid)
                    onersid, posList = rsid.strip().split(":")
                    snpLib[onersid] = {}
                    posList = posList.split(";")
                    if refver == "hg19":
                        for pos in posList:
                            if pos.startswith("hg19="):
                                # print(pos)
                                chrom, position = pos.replace("hg19=", "").split("-")
                                snpLib[onersid]["chr"] = chrom
                                snpLib[onersid]["pos"] = position
                    elif refver == "hg38":
                        for pos in posList:
                            if pos.startswith("hg38="):
                                chrom, position = pos.replace("hg38=", "").split("-")
                                snpLib[onersid]["chr"] = chrom
                                snpLib[onersid]["pos"] = position
            else:
                cellid = snp.strip().split(",")[1]
                genotypeVec = snp.strip().split(",")[3]
                genotypeVecDict = OrderedDict()
                genotypeVecList = genotypeVec.strip().split("|")
                for idx,onersid in enumerate(snpLib.keys()):
                    genotypeVecDict[onersid] = genotypeVecList[idx]

                cellines_vectors[cellid] = genotypeVecDict
            """
            snpLib
                {
                  'rs4453265', {'chr': 'chr11', 'pos': '74074281'},
                  'rs4453264', {'chr': 'chr12', 'pos': '74074241'}  
                }
            cellines_vectors
                {
                    "cvcl_0002":{"rs124":GT,"rs211",NN},
                }
            """
    return (snpLib, cellines_vectors)


def process_snpvectorA(f, LKG, test_dict):
    ref_exp=pd.read_csv(f,sep='\t',index_col=0)
    refine_LKG=list(set(LKG['lkg']).intersection(set([_ for _ in ref_exp])))
    ref_exp_LKG=ref_exp[refine_LKG]
    test_rsid=[]
    test_count=[]
    for i in test_dict:
        test_rsid.append(i)    
        test_count.append(test_dict[i])    
    test_exp=pd.DataFrame(test_count,index=test_rsid,columns=['QUERY'])
    return pd.concat([test_exp,ref_exp_LKG],axis=1)


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("-b", "--bam",required=True, help="Input Bam")
    parser.add_argument(
        "-r",
        "--refver",
        choices=["hg38", "hg19"],
        type=str.lower,
        default='hg19',
        help="Reference version of bam [hg38/hg19]",
    )
    parser.add_argument("-o", "--outprefix", default='Output', help="Output prefix")
    parser.add_argument("-q", "--mapq", required=False,default=20,type=int, help="Minimal map quality,default is 20")
    parser.add_argument("-Q", "--baseq", required=False,default=20,type=int, help="Minimal base quality,default is 20")
    parser.add_argument("-v", "--version", action="version", version=f"{currversion}")
    parser.add_argument("-V", "--verbose", action="store_true", help="verbose print")
    args = parser.parse_args()

    gvar.thismapq = args.mapq
    gvar.thisbaseq = args.baseq
    if args.verbose:
        logging.basicConfig(
            level=logging.DEBUG, format="[%(asctime)s - %(levelname)s]: %(message)s"
        )
    else:
        logging.basicConfig(
            level=logging.INFO, format="[%(asctime)s - %(levelname)s]: %(message)s"
        )

    logging.debug(args)
    main(
        bampath=args.bam,
        refVer=args.refver,
        snpvectorA=SNPvectorA,
        snpvectorB=SNPvectorB,
        outprefix=args.outprefix,
    )
