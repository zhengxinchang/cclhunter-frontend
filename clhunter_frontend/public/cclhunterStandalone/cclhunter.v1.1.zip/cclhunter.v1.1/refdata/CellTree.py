import os
import argparse
class CellTree():
    def __init__(self,CCLEAndCOSMICTree=True):
        self.Roots = []
        self.celllist = {}
        self.cellChildrenList={}
        if not CCLEAndCOSMICTree:
            fCellDB = open(os.path.join(os.path.dirname(os.path.realpath(__file__)),"CellinesProjection.txt")) 
        else:
            fCellDB = open(os.path.join(os.path.dirname(os.path.realpath(__file__)),"CellinesProjection.CutCCLEAndCOSMIC.txt")) 

        for onerelation in fCellDB:
            parent,tid,ttype,isVirtual = onerelation.strip().split("\t")
            if ttype == "Root":
                self.Roots.append(tid)
            self.celllist[tid]={
                "parent":parent,
                "isvirtual":isVirtual
            }
            if parent not in self.cellChildrenList.keys():
                self.cellChildrenList[parent]=[tid]
            else:
                self.cellChildrenList[parent].append(tid)
        fCellDB.close()
    def getRoot(self):
        return(self.Roots)
    def getParent(self,node):
        return(self.celllist.get(node.strip(),{}).get("parent",None))
    def getChildren(self,node):
        return(self.cellChildrenList.get(node.strip(),[]))
    def isVirtual(self,node):
        return(self.celllist.get(node.strip(),{}).get("isvirtual",None))
    def getAllChildren(self,node,myAllChildren=[]):
        #print(node)
        '''递归获得该ccls的全部children'''
        myChildren=self.getChildren(node)
        if myChildren:
            for per in myChildren:
                myAllChildren.append(per)
                self.getAllChildren(per,myAllChildren)
        else:
            return myChildren

if __name__ == "__main__":
    parser = argparse.ArgumentParser(prog="Cell Tree")
    parser.add_argument("--getChildren",required=False,help="getChildren")
    parser.add_argument("--getParent",required=False,help="getParent")
    parser.add_argument("--getRoot",required=False,help="getRoot",action="store_true")
    parser.add_argument("--isVirtual",required=False,help="isVirtual")
    args = parser.parse_args()

    ct = CellTree()
    if args.getChildren:    
        print(ct.getChildren(args.getChildren))
    if args.getParent:
        print(ct.getParent(args.getParent))
    if args.getRoot:
        print(ct.getRoot())
    if args.isVirtual:
        print(ct.isVirtual(args.isVirtual))        


        