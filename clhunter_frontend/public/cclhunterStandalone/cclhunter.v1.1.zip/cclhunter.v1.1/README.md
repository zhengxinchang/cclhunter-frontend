```bash
sambamba slice -L lib/hg19.cord CVCL_0002.bam >CVCL_0002.refine.bam
samtools index CVCL_0002.refine.bam
python CellID.py -b CVCL_0002.sorted.dedup.refine.bam -r hg19
```
