thismapq=None
thisbaseq=None
